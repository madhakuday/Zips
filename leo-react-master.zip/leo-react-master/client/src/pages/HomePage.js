import React from "react";
import Landing from "./Landing";

const HomePage = () => {
  return <Landing />;
};

export default HomePage;
