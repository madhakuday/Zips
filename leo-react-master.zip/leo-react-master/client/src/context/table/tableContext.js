import { createContext } from 'react';

const tableContext = createContext();

export default tableContext;
