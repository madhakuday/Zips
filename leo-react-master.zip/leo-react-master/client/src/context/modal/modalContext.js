import { createContext } from 'react';

const modalContext = createContext();

export default modalContext;
