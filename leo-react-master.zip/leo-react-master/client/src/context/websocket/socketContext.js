import { createContext } from 'react';

const socketContext = createContext();

export default socketContext;
