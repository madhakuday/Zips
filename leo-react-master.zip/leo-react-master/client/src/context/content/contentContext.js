import { createContext } from 'react';

const contentContext = createContext();

export default contentContext;
