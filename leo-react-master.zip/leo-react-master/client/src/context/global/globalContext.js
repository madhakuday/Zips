import { createContext } from 'react';

const globalContext = createContext();

export default globalContext;
