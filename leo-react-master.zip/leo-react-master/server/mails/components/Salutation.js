const Salutation = (username) => `
<tr>
  <td align="left"
    style="font-size:0px;padding:0px 25px 0px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;">
    <div
      style="font-family:Arial, sans-serif;font-size:13px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;">
      <h2 class="text-build-content" data-testid="i8L8HViE9W"
        style="margin-top: 10px; margin-bottom: 10px"><span
          style="color:#245069;font-family:Playfair Display, Helvetica, Arial, sans-serif;font-size:24px;">Hi
          ${username}!</span></h2>
    </div>
  </td>
</tr>
`;

module.exports = Salutation;
