const ContentBlock = (content) => `  
<tr>
  <td align="left" style="font-size:0px;padding:0px 25px 0px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;">
    ${content}
  </td>
</tr>`;

module.exports = ContentBlock;
