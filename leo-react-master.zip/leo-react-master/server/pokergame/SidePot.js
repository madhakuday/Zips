class SidePot {
  constructor() {
    this.amount = 0;
    this.players = [];
  }
}

module.exports = SidePot;
