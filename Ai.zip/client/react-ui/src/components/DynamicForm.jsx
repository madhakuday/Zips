import axiox from 'axios';
import React, { useState } from 'react';
import DynamicResultTable from './DynamicResultTable ';

function DynamicForm() {
  const [forms, setForms] = useState([
    {
      sepal_length: 0,
      sepal_width: 0,
      petal_length: 0,
      petal_width: 0,
      species: '',
    },
  ]);
  const [data, setData] = useState();

  const handleFormChange = (index, event) => {
    let data = [...forms];

    console.log(event.target.value);
    if (event.target.name == 'species') {
      data[index][event.target.name] = event.target.value;
    } else {
      data[index][event.target.name] = +event.target.value;
    }
    setForms(data);
  };

  const addForm = () => {
    let newForm = {
      sepal_length: 0,
      sepal_width: 0,
      petal_length: 0,
      petal_width: 0,
      species: '',
    };
    setForms([...forms, newForm]);
  };

  const submit = async (e) => {
    e.preventDefault();
    const apiUrl = 'api/getprediction';
    console.log(forms);
    const { data } = await axiox.post(apiUrl, forms);
    setData(data);
    console.log(data);
  };

  return (
    <>
      <form onSubmit={submit}>
        {forms.map((form, index) => (
          <div key={index} className="form-card">
            <input
              type="number"
              name="sepal_length"
              value={form.sepal_length}
              onChange={(e) => handleFormChange(index, e)}
              placeholder="Sepal Length"
              required
            />
            <input
              type="number"
              name="sepal_width"
              value={form.sepal_width}
              onChange={(e) => handleFormChange(index, e)}
              placeholder="Sepal Width"
              required
            />
            <input
              type="number"
              name="petal_length"
              value={form.petal_length}
              onChange={(e) => handleFormChange(index, e)}
              placeholder="Petal Length"
              required
            />
            <input
              type="number"
              name="petal_width"
              value={form.petal_width}
              onChange={(e) => handleFormChange(index, e)}
              placeholder="Petal Width"
              required
            />
            <select
              name="species"
              value={form.species}
              onChange={(e) => handleFormChange(index, e)}
              required
            >
              <option value="">Select Species</option>
              <option value="setosa">Setosa</option>
              <option value="versicolor">Versicolor</option>
              <option value="virginica">Virginica</option>
            </select>

            <hr />
          </div>
        ))}
        <button className="form-button" type="button" onClick={addForm}>
          Add Form
        </button>
        <button className="form-button" type="submit">
          Submit
        </button>
      </form>
      {data && <DynamicResultTable data={data} />}
    </>
  );
}

export default DynamicForm;
