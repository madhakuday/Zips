import React from 'react';

const DynamicResults = ({ data }) => {
  // This function determines the species based on the maximum value's index.
  const determineSpecies = (values) => {
    const maxIndex = values.indexOf(Math.max(...values));
    switch (maxIndex) {
      case 0:
        return 'setosa';
      case 1:
        return 'virginica';
      case 2:
        return 'versicolor';
      default:
        return 'Unknown';
    }
  };

  const testKeys = Object.keys(data).sort();

  const tableRows = testKeys.map((key, index) => {
    const testResults = data[key];
    const speciesName = determineSpecies(testResults);

    return (
      <tr key={index}>
        {testResults.map((result, resultIndex) => (
          <td className="App-td" key={resultIndex}>
            {result}
          </td>
        ))}
        <td className="App-td">{speciesName}</td>
      </tr>
    );
  });

  return (
    <div>
      <h1>Prediction Results</h1>
      <table className="App-table">
        <thead>
          <tr>
            <th className="App-th">Test 1</th>
            <th className="App-th">Test 2</th>
            <th className="App-th">Test 3</th>
            <th className="App-th">Species</th>
          </tr>
        </thead>
        <tbody>{tableRows}</tbody>
      </table>
    </div>
  );
};

export default DynamicResults;
